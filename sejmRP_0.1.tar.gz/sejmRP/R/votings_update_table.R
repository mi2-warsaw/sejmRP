#opis

votings_update_table <- function(dbname,user,password,host,home_page,page){
  #stopifnoty
  
  #to do
  
  return(invisible(NULL))
}