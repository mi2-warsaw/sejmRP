#opis

votes_update_table <- function(dbname,user,password,host,home_page,windows=TRUE){
  #stopifnoty
  
  #to do
  
  return(invisible(NULL))
}