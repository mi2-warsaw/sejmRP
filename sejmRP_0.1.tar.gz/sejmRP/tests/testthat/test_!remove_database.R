test_that("result of function", {
  expect_null(remove_database("sejmrp","sejmrp","x56jK99ZwQp","192.168.137.38"))
})
