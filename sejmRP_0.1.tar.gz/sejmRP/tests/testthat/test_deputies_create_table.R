test_that("result of function", {
  #expect_null(deputies_create_table("sejmrp","sejmrp",password,"192.168.137.38"))
})
