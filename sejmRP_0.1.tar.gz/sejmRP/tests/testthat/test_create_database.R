test_that("result of function", {
  #expect_null(create_database("sejmrp","sejmrp",password,"192.168.137.38"))
})
