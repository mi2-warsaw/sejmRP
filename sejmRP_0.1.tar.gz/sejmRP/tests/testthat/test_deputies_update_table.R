test_that("result of function", {
  expect_null(deputies_update_table("sejmrp","sejmrp","x56jK99ZwQp","192.168.137.38"))
})
