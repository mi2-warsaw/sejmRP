test_that("result of function", {
  #expect_null(create_database("sejmrp", "sejmrp", password, "services.mini.pw.edu.pl"))
})
