test_that("result of function", {
  #expect_null(votes_update_table("sejmrp", "sejmrp", password, "services.mini.pw.edu.pl",
  #  8, .Platform$OS.type == "windows"))
})