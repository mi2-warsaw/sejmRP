test_that("result of function", {
  #expect_null(deputies_update_table("sejmrp", "sejmrp", password, "192.168.137.38"))
})
