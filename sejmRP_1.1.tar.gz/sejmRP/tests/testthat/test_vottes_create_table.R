test_that("result of function", {
  #expect_null(votes_create_table("sejmrp", "sejmrp", password, "192.168.137.38",
  #  "http://www.sejm.gov.pl/Sejm7.nsf/", .Platform$OS.type == "windows"))
})