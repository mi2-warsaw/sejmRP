test_that("result of function", {
  #expect_null(votings_update_table("sejmrp", "sejmrp", password, "192.168.137.38",
  #  "http://www.sejm.gov.pl/Sejm7.nsf/", "http://www.sejm.gov.pl/Sejm7.nsf/agent.xsp?symbol=posglos&NrKadencji=7"))
})